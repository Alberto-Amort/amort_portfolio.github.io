﻿/*
 * Created by SharpDevelop.
 * User: alber
 * Date: 03/05/2023
 * Time: 19:52
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace amort_codice_fiscale
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Button_annullaClick(object sender, EventArgs e)
		{
			this.Close();
		}
		
		void Button_okClick(object sender, EventArgs e)
		{
			string codice_fiscale="";
			bool flag=false;
			
			
			
			foreach(char c in textBox_nome.Text)
			{
				if(Char.IsNumber(c)==true)
				{
					MessageBox.Show("Il nome può avere solo lettere", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
					textBox_nome.Text="";
					flag=true;
					break;
				}
			}
			
			foreach(char c in textBox_cognome.Text)
			{
				if(Char.IsNumber(c)==true)
				{
					MessageBox.Show("Il cognome può avere solo lettere", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
					textBox_cognome.Text="";
					flag=true;
					break;
				}
			}
			
					
			foreach(char c in textBox_comune.Text)
			{
				if(Char.IsNumber(c))
				{
					MessageBox.Show("Il cognome può avere solo lettere", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
					textBox_comune.Text="";
					flag=true;
					break;
				}
			}
			
			
			if (String.IsNullOrEmpty(Convert.ToString(textBox_nome.Text)))
			{
				MessageBox.Show("Nome Mancante", "ATTENZIONE!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);  
			}
			
			if (String.IsNullOrEmpty(Convert.ToString(textBox_cognome.Text)))
			{
				MessageBox.Show("Cognome Mancante", "ATTENZIONE!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);  
			}
			
			if (String.IsNullOrEmpty(Convert.ToString(textBox_comune.Text)))
			{
				MessageBox.Show("Comune Mancante", "ATTENZIONE!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);  
			}
			
			if (dateTimePicker1.Value.Year<1950 || dateTimePicker1.Value.Year>=2023)
			{
				MessageBox.Show("Data Non Valida", "ATTENZIONE!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
				flag=true;
			}
		
			
			if(String.IsNullOrEmpty(Convert.ToString(textBox_nome.Text))==false && String.IsNullOrEmpty(Convert.ToString(textBox_cognome.Text))==false && String.IsNullOrEmpty(Convert.ToString(textBox_comune.Text))==false && flag==false)
			{
			
			string cognome="";
			
			foreach(char c in textBox_cognome.Text.ToLower())
			
			{
				if (c!='a' && c!='e' && c!='i' && c!='o' && c!='u' && c!='à' && c!='ì' && c!='è' && c!='é' && c!='ò' && c!='ù' && cognome.Length<3)
				{
					cognome= cognome + (Convert.ToString(c)).ToUpper();
				}
				if(cognome.Length==3)
				{
					break;
				}
			}
			
			if(cognome.Length<3)
			{
				foreach(char c in textBox_cognome.Text.ToLower())
				{
					if (c=='a' || c=='e' || c=='i' || c=='o' || c=='u' || c=='à' || c=='è' || c=='é' || c=='ì' || c=='ò' || c=='ù' && cognome.Length<3)
					{
						cognome= cognome + (Convert.ToString(c)).ToUpper();
					}
					if(cognome.Length==3)
					{
						break;
					}
				}
				
			}
			
			if(cognome.Length<3){
				for(int i=0; cognome.Length<3; i++)
				{
					cognome=cognome+"X";
				}
				
			}
				
			
			
			
			codice_fiscale= codice_fiscale +  cognome;
			
			int cont=0;
			
			foreach(char c in textBox_nome.Text.ToLower())		
			{
				if (c!='a' && c!='e' && c!='i' && c!='o' && c!='u' && c!='à' && c!='ì' && c!='è' && c!='é' && c!='ò' && c!='ù')
				{
					cont++;
				}
			}
			
			string nome="";
			int y=0;
			
			foreach(char c in textBox_nome.Text.ToLower())		
			{
				if (c!='a' && c!='e' && c!='i' && c!='o' && c!='u' && c!='à' && c!='ì' && c!='è' && c!='é' && c!='ò' && c!='ù'&& nome.Length<3 && y!=1)
				{
					nome= nome + (Convert.ToString(c)).ToUpper();
				}
				if(nome.Length==3)
				{
					break;
				}
				if(c!='a' && c!='e' && c!='i' && c!='o' && c!='u' && c!='à' && c!='ì' && c!='è' && c!='é' && c!='ò' && c!='ù' && cont>=4)
				{
					y++;
				}
			}
			
			if(nome.Length<3)
			{
				foreach(char c in textBox_nome.Text.ToLower())
				{
					if (c=='a' || c=='e' || c=='i' || c=='o' || c=='u' || c=='à' || c=='è' || c=='é' || c=='ì' || c=='ò' || c=='ù' && nome.Length<3)
					{
						nome= nome + (Convert.ToString(c)).ToUpper();
					}
					if(nome.Length==3)
					{
						break;
					}
				}
				
			}
			
			if(nome.Length<3){
				for(int i=0; nome.Length<3; i++)
				{
					nome=nome+"X";
				}
				
			}
			
			codice_fiscale=codice_fiscale+nome;
			char[] anno=dateTimePicker1.Text.ToCharArray();
			codice_fiscale=codice_fiscale+anno[anno.Length-2]+anno[anno.Length-1];
			
			string mese="";
			mese=mese+dateTimePicker1.Value.Month;
			
			switch (mese)
            {
                case "1":  codice_fiscale=codice_fiscale+"A"; break;
                case "2": codice_fiscale = codice_fiscale + "B"; break;
                case "3":    codice_fiscale = codice_fiscale + "C"; break;
                case "4":   codice_fiscale = codice_fiscale + "D"; break;
                case "5":   codice_fiscale = codice_fiscale + "E"; break;
                case "6":   codice_fiscale = codice_fiscale + "H"; break;
                case "7":   codice_fiscale = codice_fiscale + "L"; break;
                case "8":   codice_fiscale = codice_fiscale + "M"; break;
                case "9": codice_fiscale = codice_fiscale + "P"; break;
                case "10":  codice_fiscale = codice_fiscale + "R"; break;
                case "11": codice_fiscale = codice_fiscale + "S"; break;
                case "12": codice_fiscale = codice_fiscale + "T"; break;
            }
			
			string data="";
			if(comboBox_sesso.Text=="Maschio")
			{
				if(Convert.ToString(dateTimePicker1.Value.Day).Length<2)
				{
					data="0"+Convert.ToString(dateTimePicker1.Value.Day);
				}
				else{
					data=Convert.ToString(dateTimePicker1.Value.Day);
				}
				
			}
			
			if(comboBox_sesso.Text=="Femmina")
			{
				data=Convert.ToString(Convert.ToInt32(dateTimePicker1.Value.Day)+40);
			}
			
			codice_fiscale=codice_fiscale+data;
			Random random=new Random();
			char[] carattere= textBox_comune.Text.ToCharArray();
			string n=Convert.ToString(random.Next(0,999));
			
			if(n.Length<3)
			{
				while(n.Length<3)
				{
					n="0" + n;
				}
				
			}
			
			codice_fiscale=codice_fiscale+(Convert.ToString(carattere[0])).ToUpper()+ n;
			
			
		int somma=0;
			int div=0;
			
			
			
			foreach(char c in codice_fiscale)
			{
				if(div%2==0)
				{
					foreach(string line in System.IO.File.ReadLines("pari.txt"))
					{
						string[] parola=line.Split(' ');
						if(parola[0]==Convert.ToString(c))
						{
							somma=somma+Convert.ToInt32(parola[parola.Length-1]);
							break;
						}
					}
				}
				
				if(div%2!=0)
				{
					foreach(string line in System.IO.File.ReadLines("dispari.txt"))
					{
						string[] parola=line.Split(' ');
						if(parola[0]==Convert.ToString(c))
						{
							somma=somma+Convert.ToInt32(parola[parola.Length-1]);
							break;
						}
					}
				}
				
				div++;
				
			}
			
			somma=somma/26;
			
			string controllo="";
			
			
			foreach(string line in System.IO.File.ReadLines("check-digit.txt"))
					{
						string[] parola=line.Split(' ');
						if(parola[0]==Convert.ToString(somma))
						{
							controllo=parola[parola.Length-1];
						}
					}
			
			codice_fiscale=codice_fiscale+controllo;
				
			
				MessageBox.Show("Codice Fiscale: " + codice_fiscale, "Completato", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				this.Close();
			}
				
		
			
	
			
	
		}
	}
}
