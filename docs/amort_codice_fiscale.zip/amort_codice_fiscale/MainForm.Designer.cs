﻿/*
 * Created by SharpDevelop.
 * User: alber
 * Date: 03/05/2023
 * Time: 19:52
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace amort_codice_fiscale
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.TextBox textBox_nome;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBox_cognome;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox comboBox_sesso;
		private System.Windows.Forms.Button button_ok;
		private System.Windows.Forms.Button button_annulla;
		private System.Windows.Forms.TextBox textBox_comune;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.Label Data;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox_nome = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBox_cognome = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.comboBox_sesso = new System.Windows.Forms.ComboBox();
			this.button_ok = new System.Windows.Forms.Button();
			this.button_annulla = new System.Windows.Forms.Button();
			this.textBox_comune = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.Data = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// textBox_nome
			// 
			this.textBox_nome.Location = new System.Drawing.Point(83, 82);
			this.textBox_nome.Margin = new System.Windows.Forms.Padding(2);
			this.textBox_nome.Name = "textBox_nome";
			this.textBox_nome.Size = new System.Drawing.Size(106, 20);
			this.textBox_nome.TabIndex = 7;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(34, 82);
			this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(38, 19);
			this.label2.TabIndex = 6;
			this.label2.Text = "Nome";
			// 
			// textBox_cognome
			// 
			this.textBox_cognome.Location = new System.Drawing.Point(83, 42);
			this.textBox_cognome.Margin = new System.Windows.Forms.Padding(2);
			this.textBox_cognome.Name = "textBox_cognome";
			this.textBox_cognome.Size = new System.Drawing.Size(106, 20);
			this.textBox_cognome.TabIndex = 5;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(34, 42);
			this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(52, 19);
			this.label1.TabIndex = 4;
			this.label1.Text = "Cognome";
			// 
			// comboBox_sesso
			// 
			this.comboBox_sesso.FormattingEnabled = true;
			this.comboBox_sesso.Items.AddRange(new object[] {
			"Maschio",
			"Femmina"});
			this.comboBox_sesso.Location = new System.Drawing.Point(83, 163);
			this.comboBox_sesso.Margin = new System.Windows.Forms.Padding(2);
			this.comboBox_sesso.Name = "comboBox_sesso";
			this.comboBox_sesso.Size = new System.Drawing.Size(92, 21);
			this.comboBox_sesso.TabIndex = 25;
			this.comboBox_sesso.Text = "Maschio";
			// 
			// button_ok
			// 
			this.button_ok.Location = new System.Drawing.Point(240, 265);
			this.button_ok.Margin = new System.Windows.Forms.Padding(2);
			this.button_ok.Name = "button_ok";
			this.button_ok.Size = new System.Drawing.Size(95, 45);
			this.button_ok.TabIndex = 24;
			this.button_ok.Text = "OK";
			this.button_ok.UseVisualStyleBackColor = true;
			this.button_ok.Click += new System.EventHandler(this.Button_okClick);
			// 
			// button_annulla
			// 
			this.button_annulla.Location = new System.Drawing.Point(99, 265);
			this.button_annulla.Margin = new System.Windows.Forms.Padding(2);
			this.button_annulla.Name = "button_annulla";
			this.button_annulla.Size = new System.Drawing.Size(89, 45);
			this.button_annulla.TabIndex = 23;
			this.button_annulla.Text = "Annulla";
			this.button_annulla.UseVisualStyleBackColor = true;
			this.button_annulla.Click += new System.EventHandler(this.Button_annullaClick);
			// 
			// textBox_comune
			// 
			this.textBox_comune.Location = new System.Drawing.Point(83, 203);
			this.textBox_comune.Margin = new System.Windows.Forms.Padding(2);
			this.textBox_comune.Name = "textBox_comune";
			this.textBox_comune.Size = new System.Drawing.Size(63, 20);
			this.textBox_comune.TabIndex = 22;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(34, 203);
			this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(52, 19);
			this.label4.TabIndex = 21;
			this.label4.Text = "Comune";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(34, 166);
			this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(38, 19);
			this.label3.TabIndex = 20;
			this.label3.Text = "Sesso";
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(83, 122);
			this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(168, 20);
			this.dateTimePicker1.TabIndex = 19;
			this.dateTimePicker1.Value = new System.DateTime(2000, 1, 1, 12, 47, 0, 0);
			// 
			// Data
			// 
			this.Data.Location = new System.Drawing.Point(34, 122);
			this.Data.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.Data.Name = "Data";
			this.Data.Size = new System.Drawing.Size(52, 34);
			this.Data.TabIndex = 18;
			this.Data.Text = "Data di Nascita";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.ClientSize = new System.Drawing.Size(438, 361);
			this.Controls.Add(this.comboBox_sesso);
			this.Controls.Add(this.button_ok);
			this.Controls.Add(this.button_annulla);
			this.Controls.Add(this.textBox_comune);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.Data);
			this.Controls.Add(this.textBox_nome);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textBox_cognome);
			this.Controls.Add(this.label1);
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "MainForm";
			this.Text = "amort_codice_fiscale";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
